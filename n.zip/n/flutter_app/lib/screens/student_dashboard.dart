import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/auth_storage.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  bool _loading = true;
  List<dynamic> _records = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      _records = await ApiService.getMyAttendance();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  int get totalDays => _records.length;
  int get presentDays => _records.where((r) => (r['status'] as String).toLowerCase() == 'present').length;
  int get percent => totalDays == 0 ? 0 : ((presentDays * 100) / totalDays).round();

  Future<void> _logout() async {
    await AuthStorage.clear();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        actions: [IconButton(onPressed: _logout, icon: const Icon(Icons.logout))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  Card(
                    child: ListTile(
                      title: Text('Attendance: $percent%'),
                      subtitle: Text('Present $presentDays / Total $totalDays'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  ..._records.map((r) {
                    final status = (r['status'] as String);
                    final isPresent = status.toLowerCase() == 'present';
                    final dateStr = (r['date_str'] ?? '').toString();
                    return Card(
                      color: isPresent ? Colors.green.shade50 : Colors.red.shade50,
                      child: ListTile(
                        leading: Icon(isPresent ? Icons.check_circle : Icons.cancel,
                            color: isPresent ? Colors.green : Colors.red),
                        title: Text(dateStr),
                        trailing: Text(status,
                            style: TextStyle(
                              color: isPresent ? Colors.green : Colors.red,
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                    );
                  })
                ],
              ),
            ),
    );
  }
}
