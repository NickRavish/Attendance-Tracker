import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/auth_storage.dart';

class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({super.key});
  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  bool _loading = true; // overall loading
  List<dynamic> _students = []; // [{id, name, email}]
  List<dynamic> _attendance = []; // all attendance rows

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      // Fetch students and all attendance in parallel
      final results = await Future.wait([
        ApiService.getStudents(),
        ApiService.getAllAttendance(),
      ]);
      _students = results[0];
      _attendance = results[1];
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // Compute present/total per student and percentage
  Map<int, Map<String, int>> _computeStats() {
    final Map<int, Map<String, int>> map = {};
    for (final row in _attendance) {
      final sid = row['student_id'] as int;
      map.putIfAbsent(sid, () => {'present': 0, 'total': 0});
      map[sid]!['total'] = (map[sid]!['total'] ?? 0) + 1;
      if ((row['status'] as String).toLowerCase() == 'present') {
        map[sid]!['present'] = (map[sid]!['present'] ?? 0) + 1;
      }
    }
    return map;
  }

  Future<void> _logout() async {
    await AuthStorage.clear();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    final stats = _computeStats();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Dashboard'),
        actions: [
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _loading ? null : () => _openMarkAttendance(context),
        label: const Text('Mark Attendance'),
        icon: const Icon(Icons.checklist_rtl),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: _students.length,
                itemBuilder: (context, idx) {
                  final s = _students[idx];
                  final sid = s['id'] as int;
                  final total = stats[sid]?['total'] ?? 0;
                  final present = stats[sid]?['present'] ?? 0;
                  final pct = total == 0 ? 0 : ((present * 100) / total).round();
                  return Card(
                    child: ListTile(
                      title: Text(s['name'] ?? ''),
                      subtitle: Text(s['email'] ?? ''),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('$pct%', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text('($present/$total)')
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  Future<void> _openMarkAttendance(BuildContext context) async {
    final formKey = GlobalKey<FormState>();
    int? selectedStudentId = _students.isNotEmpty ? (_students.first['id'] as int) : null;
    DateTime date = DateTime.now();
    String status = 'Present';

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 16, left: 16, right: 16, top: 16),
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Mark Attendance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  value: selectedStudentId,
                  items: _students
                      .map<DropdownMenuItem<int>>((s) => DropdownMenuItem(
                            value: s['id'] as int,
                            child: Text(s['name']),
                          ))
                      .toList(),
                  onChanged: (v) => selectedStudentId = v,
                  validator: (v) => v == null ? 'Select student' : null,
                  decoration: const InputDecoration(labelText: 'Student'),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('Date: ${date.toIso8601String().substring(0, 10)}')),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: date,
                          firstDate: DateTime(2020),
                          lastDate: DateTime(2100),
                        );
                        if (picked != null) {
                          setState(() => date = picked);
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: status,
                  items: const [
                    DropdownMenuItem(value: 'Present', child: Text('Present')),
                    DropdownMenuItem(value: 'Absent', child: Text('Absent')),
                  ],
                  onChanged: (v) => status = v ?? 'Present',
                  decoration: const InputDecoration(labelText: 'Status'),
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;
                    final dateStr = date.toIso8601String().substring(0, 10);
                    try {
                      final resp = await ApiService.markAttendance(selectedStudentId!, dateStr, status);
                      if (resp['error'] != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Failed: ${resp['error']}'), backgroundColor: Colors.red),
                        );
                      } else {
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Attendance recorded'), backgroundColor: Colors.green),
                        );
                        Navigator.pop(context);
                        await _load();
                      }
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
                      );
                    }
                  },
                  child: const Text('Submit'),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        );
      },
    );
  }
}
