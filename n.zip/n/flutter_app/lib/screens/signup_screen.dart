import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/auth_storage.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  String _role = 'student';
  bool _loading = false;

  void _snack(String msg, {Color? c}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: c));
  }

  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final resp = await ApiService.register(_nameCtrl.text.trim(), _emailCtrl.text.trim(), _passwordCtrl.text, _role);
      if (resp['id'] != null) {
        // Immediately login
        final login = await ApiService.login(_emailCtrl.text.trim(), _passwordCtrl.text);
        if (login['token'] != null) {
          await AuthStorage.saveAuth(login['token'], _role);
          _snack('Signup successful', c: Colors.green);
          if (!mounted) return;
          Navigator.of(context).pushReplacementNamed(_role == 'teacher' ? '/teacher' : '/student');
        } else {
          _snack('Signup ok, login failed', c: Colors.orange);
        }
      } else {
        _snack(resp['error']?.toString() ?? 'Signup failed', c: Colors.red);
      }
    } catch (e) {
      _snack('Error: $e', c: Colors.red);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign up')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (v) => (v == null || v.isEmpty) ? 'Enter name' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _emailCtrl,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) => (v == null || v.isEmpty) ? 'Enter email' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _passwordCtrl,
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (v) => (v == null || v.length < 4) ? 'Min 4 chars' : null,
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _role,
                items: const [
                  DropdownMenuItem(value: 'teacher', child: Text('Teacher')),
                  DropdownMenuItem(value: 'student', child: Text('Student')),
                ],
                onChanged: (v) => setState(() => _role = v ?? 'student'),
                decoration: const InputDecoration(labelText: 'Role'),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _loading ? null : _signup,
                icon: const Icon(Icons.app_registration),
                label: _loading ? const Text('Signing up...') : const Text('Sign up'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
