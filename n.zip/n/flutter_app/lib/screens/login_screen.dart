import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../services/auth_storage.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  String _role = 'teacher';
  bool _loading = false;

  // Helper to show snackbars
  void _snack(String msg, {Color? c}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: c),
    );
  }

  // Decode JWT payload safely to read the user's role from backend
  Map<String, dynamic>? _decodeJwt(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return null;
      final payload = base64Url.normalize(parts[1]);
      final payloadMap = jsonDecode(utf8.decode(base64Url.decode(payload)));
      if (payloadMap is Map<String, dynamic>) return payloadMap;
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final resp = await ApiService.login(_emailCtrl.text.trim(), _passwordCtrl.text);
      final token = resp['token'];
      if (token != null) {
        final payload = _decodeJwt(token);
        final backendRole = payload?['role']?.toString();
        if (backendRole == null) {
          _snack('Login failed: invalid token', c: Colors.red);
          return;
        }
        // Enforce that the selected role matches backend role
        if (backendRole != _role) {
          _snack("Role mismatch: you selected '$_role' but your account role is '$backendRole'", c: Colors.red);
          return;
        }
        // Save token and actual backend role
        await AuthStorage.saveAuth(token, backendRole);
        _snack('Login successful', c: Colors.green);
        if (!mounted) return;
        Navigator.of(context).pushReplacementNamed(backendRole == 'teacher' ? '/teacher' : '/student');
      } else {
        _snack(resp['error']?.toString() ?? 'Login failed', c: Colors.red);
      }
    } catch (e) {
      _snack('Error: $e', c: Colors.red);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text('Welcome back! Please login to continue.'),
              const SizedBox(height: 16),
              TextFormField(
                controller: _emailCtrl,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) => (v == null || v.isEmpty) ? 'Enter email' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _passwordCtrl,
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (v) => (v == null || v.length < 4) ? 'Min 4 chars' : null,
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _role,
                items: const [
                  DropdownMenuItem(value: 'teacher', child: Text('Teacher')),
                  DropdownMenuItem(value: 'student', child: Text('Student')),
                ],
                onChanged: (v) => setState(() => _role = v ?? 'teacher'),
                decoration: const InputDecoration(labelText: 'Role'),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _loading ? null : _login,
                icon: const Icon(Icons.login),
                label: _loading ? const Text('Logging in...') : const Text('Login'),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.of(context).pushNamed('/signup'),
                child: const Text('No account? Sign up'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
