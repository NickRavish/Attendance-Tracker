import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Change baseUrl if your backend runs on a different port/host.
// IMPORTANT for Android emulator: use 10.0.2.2 instead of localhost.
class ApiService {
  // Per requirements, default to port 3000. If your backend runs on 3001, change here.
  static const String baseUrl = 'http://10.0.2.2:3001/api';

  static Future<Map<String, String>> _headers({bool auth = false}) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
    };
    if (auth) {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('token');
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  static Future<Map<String, dynamic>> register(
      String name, String email, String password, String role) async {
    final resp = await http.post(Uri.parse('$baseUrl/register'),
        headers: await _headers(),
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
          'role': role,
        }));
    return _json(resp);
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final resp = await http.post(Uri.parse('$baseUrl/login'),
        headers: await _headers(),
        body: jsonEncode({'email': email, 'password': password}));
    return _json(resp);
  }

  static Future<List<dynamic>> getStudents() async {
    final resp = await http.get(Uri.parse('$baseUrl/students'), headers: await _headers(auth: true));
    return _jsonList(resp);
  }

  static Future<Map<String, dynamic>> markAttendance(
      int studentId, String dateStr, String status) async {
    final resp = await http.post(Uri.parse('$baseUrl/attendance'),
        headers: await _headers(auth: true),
        body: jsonEncode({'student_id': studentId, 'date': dateStr, 'status': status}));
    return _json(resp);
  }

  static Future<List<dynamic>> getAllAttendance() async {
    final resp = await http.get(Uri.parse('$baseUrl/attendance'), headers: await _headers(auth: true));
    return _jsonList(resp);
  }

  static Future<List<dynamic>> getMyAttendance() async {
    final resp = await http.get(Uri.parse('$baseUrl/myattendance'), headers: await _headers(auth: true));
    return _jsonList(resp);
  }

  static Map<String, dynamic> _json(http.Response resp) {
    final body = resp.body.isEmpty ? '{}' : resp.body;
    try {
      final parsed = jsonDecode(body);
      if (resp.statusCode >= 200 && resp.statusCode < 300) return parsed;
      return {'error': parsed['error'] ?? 'Request failed', 'status': resp.statusCode};
    } catch (_) {
      return {'error': 'Invalid server response', 'status': resp.statusCode};
    }
  }

  static List<dynamic> _jsonList(http.Response resp) {
    final body = resp.body.isEmpty ? '[]' : resp.body;
    try {
      if (resp.statusCode >= 200 && resp.statusCode < 300) return jsonDecode(body) as List<dynamic>;
      final parsed = jsonDecode(body);
      throw Exception(parsed['error'] ?? 'Request failed');
    } catch (e) {
      throw Exception('Invalid response: $e');
    }
  }
}
