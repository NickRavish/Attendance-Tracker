# Student Attendance — Flutter App

This is the Flutter frontend for the Student Attendance System.

## Requirements
- Flutter 3 (stable), Dart SDK 3+
- Dependencies are in `pubspec.yaml`: http, shared_preferences

## Configure API base URL
- Edit `lib/services/api_service.dart` and set `baseUrl` to your backend.
  - Default in code: http://localhost:3000/api (as per your spec)
  - If your backend runs on port 3001, change it accordingly.
  - Android emulator: replace `localhost` with `10.0.2.2`.

## Run
```bash
cd 'flutter_app'
flutter pub get
flutter run -d android    # or choose your device
```

## Screens
- Login: email, password, role dropdown
- Signup: name, email, password, role
- Teacher Dashboard: students list with percentages, mark attendance form
- Student Dashboard: my attendance list and summary

## Notes
- JWT token + role stored via shared_preferences
- Material 3 theme enabled
- Shows loading indicators and snackbars on errors

See `FLUTTER_EXPLAINED.md` for a deeper explanation.