# Flutter Frontend — What and Why

This app is a simple, commented Flutter frontend using Material 3 that talks to the Node/Express backend.

What we use and why:
- Material 3 (ThemeData.useMaterial3): modern look and consistent components.
- http: lightweight HTTP client for REST calls.
- shared_preferences: simple key-value store to persist JWT token and role across app restarts.
- Screens: Login, Signup, TeacherDashboard, StudentDashboard — kept small and readable.
- Services: ApiService (all HTTP logic) and AuthStorage (persist token/role).

Navigation flow:
- main.dart -> _SplashRouter reads shared_preferences and redirects to /teacher or /student, else /login.
- Login/Signup store token+role; dashboards read token via ApiService for protected endpoints.

Backend expectations:
- Base URL in `lib/services/api_service.dart` defaults to http://localhost:3000/api per your spec. If your backend is on 3001, change it there.
- On Android emulator, use host 10.0.2.2 instead of localhost.
- Teacher endpoints require teacher token; student endpoints require student token.

Testing tips:
- Start backend on your machine and run the app in an emulator or device.
- If calling from Android emulator, change base URL host to 10.0.2.2.
- If you see CORS issues in Flutter Web, prefer mobile (Android) for the demo.

Next steps (nice-to-haves):
- State management with Provider or Riverpod for larger apps.
- Better form validation and input helpers.
- Error boundary screens and retry buttons.
- Students list paging or search if the list grows.
