const express = require('express');
const db = require('../db');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

const router = express.Router();

// Protect endpoints with teacher role
router.use(['/attendance', '/students'], authenticateToken, authorizeRole('teacher'));

// Mark attendance
router.post('/attendance', async (req, res) => {
  try {
    const { student_id, date, status } = req.body;
    if (!student_id || !date || !status) return res.status(400).json({ error: 'student_id, date, status required' });
    if (!['Present', 'Absent'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const result = await db.query(
      'INSERT INTO attendance(student_id, date, status) VALUES($1,$2,$3) RETURNING *',
      [student_id, date, status]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not record attendance' });
  }
});

// Get all attendance
router.get('/attendance', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT a.id, a.student_id, u.name as student_name, to_char(a.date, 'YYYY-MM-DD') AS date_str, a.status
       FROM attendance a
       JOIN users u ON u.id = a.student_id
       ORDER BY a.date DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch attendance' });
  }
});

// Get attendance for one student
router.get('/attendance/:student_id', async (req, res) => {
  try {
    const { student_id } = req.params;
    const result = await db.query(
      `SELECT a.id, a.student_id, u.name as student_name, to_char(a.date, 'YYYY-MM-DD') AS date_str, a.status
       FROM attendance a
       JOIN users u ON u.id = a.student_id
       WHERE a.student_id = $1
       ORDER BY a.date DESC`,
      [student_id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch student attendance' });
  }
});

module.exports = router;

// List all students for teacher dropdowns and dashboard
router.get('/students', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, name, email FROM users WHERE role = 'student' ORDER BY name ASC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch students' });
  }
});
