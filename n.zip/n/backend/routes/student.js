const express = require('express');
const db = require('../db');
const { authenticateToken, authorizeRole } = require('../middleware/auth');

const router = express.Router();

// Protect student routes
router.use(authenticateToken, authorizeRole('student'));

// Get logged-in student's attendance
router.get('/myattendance', async (req, res) => {
  try {
    const studentId = req.user.id;
    const result = await db.query(
      `SELECT a.id, a.student_id, to_char(a.date, 'YYYY-MM-DD') AS date_str, a.status
       FROM attendance a
       WHERE a.student_id = $1
       ORDER BY a.date DESC`,
      [studentId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch attendance' });
  }
});

module.exports = router;
