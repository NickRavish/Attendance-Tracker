#!/usr/bin/env zsh
set -e

BASE="http://localhost:3001"

echo "Waiting for server at $BASE (timeout 15s)"
for i in {1..15}; do
  if curl -sS "$BASE/" >/dev/null 2>&1; then
    echo "\nServer is up"
    break
  else
    echo -n "."
    sleep 1
  fi
  if [ "$i" -eq 15 ]; then
    echo "\nERROR: server did not respond on $BASE/ after 15s"; exit 1
  fi
done

print_resp(){
  local label="$1"; shift
  echo
  echo "===== $label ====="
  echo
  echo "$@"
}

# Helper to extract token from login response JSON
get_token(){
  echo "$1" | node -e "let s=''; process.stdin.setEncoding('utf8'); process.stdin.on('data',d=>s+=d); process.stdin.on('end',()=>{try{const j=JSON.parse(s); console.log(j.token||'') }catch(e){console.error(s); process.exit(0)}})"
}

# Register users (ignore errors if exist)
TREG=$(curl -s -X POST "$BASE/api/register" -H "Content-Type: application/json" -d '{"name":"Teacher Test","email":"teacher@test.local","password":"teachpass","role":"teacher"}')
print_resp "register teacher" "$TREG"

S1REG=$(curl -s -X POST "$BASE/api/register" -H "Content-Type: application/json" -d '{"name":"Student One","email":"student1@test.local","password":"studpass","role":"student"}')
print_resp "register student1" "$S1REG"

S2REG=$(curl -s -X POST "$BASE/api/register" -H "Content-Type: application/json" -d '{"name":"Student Two","email":"student2@test.local","password":"studpass","role":"student"}')
print_resp "register student2" "$S2REG"

# Login
TLOGIN=$(curl -s -X POST "$BASE/api/login" -H "Content-Type: application/json" -d '{"email":"teacher@test.local","password":"teachpass"}')
TEACHER_TOKEN=$(get_token "$TLOGIN")
print_resp "teacher login raw" "$TLOGIN"

authorize_check(){
  if [ -z "$1" ]; then
    echo "(no token)"
  else
    echo "token len=${#1}"
  fi
}

echo "teacher token:"; authorize_check "$TEACHER_TOKEN"

S1LOGIN=$(curl -s -X POST "$BASE/api/login" -H "Content-Type: application/json" -d '{"email":"student1@test.local","password":"studpass"}')
STUDENT1_TOKEN=$(get_token "$S1LOGIN")
print_resp "student1 login raw" "$S1LOGIN"
echo "student1 token:"; authorize_check "$STUDENT1_TOKEN"

S2LOGIN=$(curl -s -X POST "$BASE/api/login" -H "Content-Type: application/json" -d '{"email":"student2@test.local","password":"studpass"}')
STUDENT2_TOKEN=$(get_token "$S2LOGIN")
print_resp "student2 login raw" "$S2LOGIN"
echo "student2 token:"; authorize_check "$STUDENT2_TOKEN"

# Extract IDs from tokens (payload contains id)
get_id_from_token(){
  echo "$1" | node -e "const t=process.argv[1]||''; if(!t){console.log(''); process.exit(0);} try{const payload=JSON.parse(Buffer.from(t.split('.')[1],'base64').toString()); console.log(payload.id||'')}catch(e){console.log('');}" "$1"
}

STU1_ID=$(get_id_from_token "$STUDENT1_TOKEN")
STU2_ID=$(get_id_from_token "$STUDENT2_TOKEN")
TEA_ID=$(get_id_from_token "$TEACHER_TOKEN")

echo "IDs -> teacher:$TEA_ID student1:$STU1_ID student2:$STU2_ID"

# Teacher marks attendance for student1 and student2
A1=$(curl -s -X POST "$BASE/api/attendance" -H "Authorization: Bearer $TEACHER_TOKEN" -H "Content-Type: application/json" -d "{\"student_id\": $STU1_ID, \"date\": \"2025-11-03\", \"status\": \"Present\"}")
print_resp "teacher mark attendance student1" "$A1"

A2=$(curl -s -X POST "$BASE/api/attendance" -H "Authorization: Bearer $TEACHER_TOKEN" -H "Content-Type: application/json" -d "{\"student_id\": $STU2_ID, \"date\": \"2025-11-03\", \"status\": \"Absent\"}")
print_resp "teacher mark attendance student2" "$A2"

# Teacher get all attendance
ALLA=$(curl -s -X GET "$BASE/api/attendance" -H "Authorization: Bearer $TEACHER_TOKEN")
print_resp "teacher get all attendance" "$ALLA"

# Teacher get attendance for student1
ONEA=$(curl -s -X GET "$BASE/api/attendance/$STU1_ID" -H "Authorization: Bearer $TEACHER_TOKEN")
print_resp "teacher get attendance for student1" "$ONEA"

# Student get own attendance
MYA=$(curl -s -X GET "$BASE/api/myattendance" -H "Authorization: Bearer $STUDENT1_TOKEN")
print_resp "student1 get myattendance" "$MYA"

# Negative tests
# Student tries to mark attendance -> should be forbidden
SATT=$(curl -s -o - -w "%{http_code}" -X POST "$BASE/api/attendance" -H "Authorization: Bearer $STUDENT1_TOKEN" -H "Content-Type: application/json" -d "{\"student_id\": $STU2_ID, \"date\": \"2025-11-03\", \"status\": \"Present\"}")
print_resp "student tries to mark attendance (http_code in output)" "$SATT"

# Teacher tries to access student-only route -> should be forbidden
TST=$(curl -s -o - -w "%{http_code}" -X GET "$BASE/api/myattendance" -H "Authorization: Bearer $TEACHER_TOKEN")
print_resp "teacher access /api/myattendance (http_code in output)" "$TST"

echo "\nAll tests done."
