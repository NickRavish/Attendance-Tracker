# Student Attendance System — Presentation

Slide 1 — Title
- Student Attendance System
- Your name, date

Slide 2 — Goal
- Build a mobile app to record and view student attendance. Backend: Node.js. Frontend: Flutter.

Slide 3 — Architecture
- Simple Express API (file-based JSON storage) for quick demo
- Flutter mobile app that calls API

Slide 4 — Demo steps
1. Start backend: `cd backend && npm install && npm start`
2. Open app on Android device/emulator
3. Add students and mark attendance

Slide 5 — Notes
- For production, replace file storage with a real DB (SQLite, Postgres). Add auth.
