# Student Attendance System

Complete Node.js + Express + PostgreSQL backend and a Flutter (Material 3) mobile app for managing student attendance.

## Tech stack
- Backend: Node.js, Express, PostgreSQL, JWT, bcryptjs, cors, dotenv
- Frontend: Flutter 3 (Dart), http, shared_preferences (Material 3 UI)

## Repo structure
- `backend/` — API server with PostgreSQL
- `flutter_app/` — Flutter client app
- `PRESENTATION.md` — slide-ready outline for your demo
- `flutter_app/FLUTTER_EXPLAINED.md` — what the Flutter app uses and why

---

## Backend (Node + Express + PostgreSQL)
Location: `backend/`

### Requirements
- Node.js 18+
- PostgreSQL 13+

### Setup
1) Create DB and tables
```bash
# Create the database (or use psql)
createdb attendance_db

# Create tables
psql -d attendance_db -f backend/init.sql
```

2) Configure environment
```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your DB credentials
# PORT defaults to 3001 in server.js
```

3) Install and run
```bash
cd backend
npm install
npm run dev   # or: npm start
```
Server runs at: `http://localhost:3001`

### API summary
Auth
- POST `/api/register` — body: `{ name, email, password, role }` (role: 'teacher'|'student')
- POST `/api/login` — body: `{ email, password }` → returns `{ token }`

Teacher (JWT, role=teacher)
- POST `/api/attendance` — body: `{ student_id, date:'YYYY-MM-DD', status:'Present'|'Absent' }`
- GET `/api/attendance` — list all attendance records
- GET `/api/attendance/:student_id` — list records for one student
- GET `/api/students` — list all students (for dropdowns)

Student (JWT, role=student)
- GET `/api/myattendance` — list own attendance

Notes
- Responses are JSON. Errors: `{ error: '...' }`
- Attendance SELECTs also return `date_str: 'YYYY-MM-DD'` to avoid timezone issues.

### Quick test (curl)
```bash
# In one terminal, ensure the server is up (backend/): npm run dev

# In another terminal, run the full test script
"/Users/harshvardhansinghkhurmi/Student Attendance System/backend/test_api.sh"

# Or a quick smoke test
curl -s http://localhost:3001/
```

---

## Frontend (Flutter)
Location: `flutter_app/`

### Requirements
- Flutter 3 (stable), Dart 3+
- Android Studio (for emulator) or run on macOS/Chrome

### Configure API base URL
- Android emulator must use host `10.0.2.2` to reach your machine.
- macOS/Chrome can use `localhost`.

Edit `flutter_app/lib/services/api_service.dart` → `baseUrl`:
- Android emulator example: `http://10.0.2.2:3001/api`
- macOS/Chrome example: `http://localhost:3001/api`

### Run
```bash
cd "flutter_app"
flutter pub get

# Android emulator
flutter devices                # verify emulator id
flutter run -d emulator-5554

# macOS desktop
flutter run -d macos

# Chrome (web)
flutter run -d chrome
```

### App features
- Login: email, password, role dropdown (role must match backend role; enforced client-side)
- Signup: name, email, password, role (auto-login then route based on role)
- Teacher dashboard: students list with attendance %, mark attendance form
- Student dashboard: my attendance list (date/status) + summary
- JWT token + role stored in `shared_preferences`
- Material 3, loading states, and snackbars for errors

---

## Troubleshooting
- Port in use (3001): stop other processes or change `PORT` in `.env`
- Android NDK error: remove broken NDK and let Gradle re-download
	```bash
	rm -rf "$HOME/Library/Android/sdk/ndk/27.0.12077973"
	cd "flutter_app" && flutter clean && flutter pub get && flutter run -d emulator-5554
	```
- Emulator networking: Android uses `10.0.2.2` to reach host `localhost`
- Cleartext HTTP: already enabled in app manifest (`usesCleartextTraffic="true"`)

---

## Presentation
- Start backend, then the app (emulator or macOS).
- Demo: sign up teacher + students, login as teacher, mark attendance, login as student to view history.
- See `PRESENTATION.md` and `flutter_app/FLUTTER_EXPLAINED.md` for slides and narrative.

## License
MIT (see `package.json` in backend). Add a LICENSE file if publishing.
